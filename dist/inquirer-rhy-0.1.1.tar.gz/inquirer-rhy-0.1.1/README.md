<h1 style="text-align: center"> inquirer-rhy </h1>

## Note

This project forked from [PyInquirer](https://github.com/CITGuru/PyInquirer)

## Install

```shell
pip3 install inquirer-rhy
```

