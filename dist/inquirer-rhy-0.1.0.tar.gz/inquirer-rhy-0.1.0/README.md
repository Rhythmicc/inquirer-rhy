<h1 style="text-align: center"> inquirer-rhy </h1>

## Install
```shell
pip3 install inquirer-rhy
```

## About this Template

- make release: `qrun -b`
- upload with twice: `qrun [-r]`

